export const REGISTER = "REGISTER";
export const LOGIN_USER = "LOGIN_USER";
export const REQ_USER = "REQ_USER";
export const SEARCH_USER = "SEARCH_USER";
export const UPDATE_USER = "UPDATE_USER";
export const LOGOUT_USER = "LOGOUT_USER";