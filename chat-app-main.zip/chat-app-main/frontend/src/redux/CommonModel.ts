export type Action = {
    type: string,
    payload: any,
}