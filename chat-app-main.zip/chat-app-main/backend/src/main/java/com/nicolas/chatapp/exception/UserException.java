package com.nicolas.chatapp.exception;

public class UserException extends Exception {

    public UserException(String message) {
        super(message);
    }

}
