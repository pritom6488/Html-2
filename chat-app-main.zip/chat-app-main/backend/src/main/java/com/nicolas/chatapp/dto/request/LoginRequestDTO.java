package com.nicolas.chatapp.dto.request;

public record LoginRequestDTO(String email, String password) {
}
