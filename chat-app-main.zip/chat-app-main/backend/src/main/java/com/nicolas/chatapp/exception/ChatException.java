package com.nicolas.chatapp.exception;

public class ChatException extends Exception{

    public ChatException(String message) {
        super(message);
    }

}
